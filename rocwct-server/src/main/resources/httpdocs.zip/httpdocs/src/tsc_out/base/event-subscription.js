export var Events;
(function (Events) {
    Events[Events["a"] = 0] = "a";
    Events[Events["b"] = 1] = "b";
})(Events || (Events = {}));
export class EventSubscription {
}
