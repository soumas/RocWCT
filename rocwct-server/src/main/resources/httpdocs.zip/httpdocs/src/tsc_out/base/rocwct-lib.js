var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { LitElement, html, css, property } from 'lit-element';
import * as rocwct from '../rocwct';
/***********************************************************/
/**************** RocWct Lit Elment ************************/
/***********************************************************/
export class RocWctLitElement extends LitElement {
    constructor() {
        super();
        this.iconSetRoot = "/images/iconset-default";
    }
    static get stylesRocWctLitElement() {
        return [
            css `:host { display: block; width: 100%; height: 100%;font-family: Arial, "Helvetica Neue", Helvetica, sans-serif; font-size: 10px; color: #7E888A }`,
        ];
    }
    registerServerEvent(event, serverEventHandler) {
        let evnt = new ServerEventSubscription();
        evnt.element = this;
        evnt.event = event;
        evnt.onServerEvent = serverEventHandler;
        rocwct.subscribe(evnt);
    }
}
export class RocWctLocoDependentElement extends RocWctLitElement {
    static get stylesRocWctLocoDependentElement() {
        return [
            RocWctLitElement.stylesRocWctLitElement
        ];
    }
    updated(changedProperties) {
        if (changedProperties.has('locoId')) {
            this.onLocoIdChange();
        }
    }
    handleLocoEvent(event, callback) {
        if (event.lc.id !== this.locoId) {
            return;
        }
        callback(event);
    }
}
export class RocWctButton extends RocWctLitElement {
    constructor() {
        super();
        this.on = null;
        this.hideLabel = false;
        this.disabled = false;
    }
    static get stylesRocWctButton() {
        return [
            RocWctLitElement.stylesRocWctLitElement,
            css `input[type="button"] { cursor:pointer;  width:100%; height: 70%; border: none; text-align: center; background-color: #7E888A;}`,
            css `input[type="button"] + div { width:100%; min-height: 30%; text-align: center; cursor:pointer; }`,
            css `input[type="button"].on { background-color: #FCAE01; }`,
            css `input[type="button"]:active { -webkit-transform: scale(0.94); transform: scale(0.94); }`,
            css `input[type="button"]:disabled { cursor: default; opacity: 0.4; -webkit-transform: none; transform: none;}`,
            css `input[type="button"]:disabled + div { cursor: default; opacity: 0.4; }`
        ];
    }
    render() {
        return html `${this.on != null
            ? html `<input id="btn" @click="${this.handleClickInternal}" title="${this.label}${this.disabled ? " (inaktiv)" : ""}" type="button" ?disabled="${this.disabled === true}" class="${this.on === true ? "on" : ""}" style="-webkit-mask: url(${this.iconSetRoot}/${this.icon}) no-repeat center; mask: url(${this.iconSetRoot}/${this.icon}) no-repeat center;"   />
                 <div @click="${this.handleClickInternal}"><label for="btn" style="display:${this.hideLabel === true ? 'none' : ''}" >${this.label}</label></div>`
            : html ``}`;
    }
    handleClickInternal() {
        if (this.disabled === true) {
            return;
        }
        this.handleClick();
    }
}
__decorate([
    property({ type: Boolean })
], RocWctButton.prototype, "on", void 0);
__decorate([
    property({ type: Boolean, attribute: "hide-label" })
], RocWctButton.prototype, "hideLabel", void 0);
__decorate([
    property({ type: Boolean, attribute: "disabled" })
], RocWctButton.prototype, "disabled", void 0);
export class RocWctLocoDependentButton extends RocWctButton {
    static get stylesRocWctLocoDependentButton() {
        return [
            RocWctButton.stylesRocWctButton,
        ];
    }
    updated(changedProperties) {
        if (changedProperties.has('locoId')) {
            this.onLocoIdChange();
        }
    }
    handleLocoEvent(event, callback) {
        if (event.lc.id !== this.locoId) {
            return;
        }
        callback(event);
    }
}
/***********************************************************/
/******************* common enums  *************************/
/***********************************************************/
export var EVMode;
(function (EVMode) {
    EVMode[EVMode["percent"] = 0] = "percent";
    EVMode[EVMode["kmh"] = 1] = "kmh";
})(EVMode || (EVMode = {}));
/***********************************************************/
/******************* Server Events *************************/
/***********************************************************/
export class ServerEventSubscription {
}
export var EServerEvent;
(function (EServerEvent) {
    EServerEvent[EServerEvent["plan"] = 0] = "plan";
    EServerEvent[EServerEvent["lc"] = 1] = "lc";
    EServerEvent[EServerEvent["auto"] = 2] = "auto";
    EServerEvent[EServerEvent["clock"] = 3] = "clock";
    EServerEvent[EServerEvent["fn"] = 4] = "fn";
    EServerEvent[EServerEvent["state"] = 5] = "state";
    EServerEvent[EServerEvent["lclist"] = 6] = "lclist";
})(EServerEvent || (EServerEvent = {}));
//# sourceMappingURL=rocwct-lib.js.map