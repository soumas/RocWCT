import { LitElement } from 'lit-element';
export class RocWctLitElement extends LitElement {
    constructor() {
        super();
    }
}
