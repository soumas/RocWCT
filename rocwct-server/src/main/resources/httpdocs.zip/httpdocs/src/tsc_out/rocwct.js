var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import { EServerEvent } from './base/rocwct-lib';
window.onload = function () {
    init();
};
var socket;
let subscribtions = [];
function init() {
    initWebSocket();
}
function initWebSocket() {
    let socketPort = new URL(document.URL).searchParams.get("port");
    if (!socketPort) {
        socketPort = "8053";
    }
    socket = new WebSocket("ws://" + location.hostname + ":" + socketPort);
    socket.onopen = function () {
        log("websocket connection is open");
    };
    socket.onmessage = function (evt) {
        log("<<<< IN: ");
        log(evt.data);
        var data = JSON.parse(evt.data);
        subscribtions.forEach(subscribtion => {
            let eventName = EServerEvent[subscribtion.event];
            if (data.hasOwnProperty(eventName)) {
                if (!subscribtion.id || subscribtion.id === eval('data[eventName]').id) {
                    subscribtion.onServerEvent(data, subscribtion.event);
                }
            }
        });
    };
    socket.onclose = function () {
        log("websocket connection is closed");
    };
}
function log(msg) {
    console.log(msg);
}
export function unsubscribe(component) {
    // TODO
}
export function subscribe(subscribtion) {
    subscribtions.push(subscribtion);
}
export function send(message) {
    return __awaiter(this, void 0, void 0, function* () {
        // wait till socket is ready
        while (socket == null || socket.readyState !== socket.OPEN) {
            yield new Promise(resolve => setTimeout(resolve, 100));
        }
        // send message
        log(">>>> OUT: ");
        log(message);
        socket.send(message);
    });
}
//# sourceMappingURL=rocwct.js.map