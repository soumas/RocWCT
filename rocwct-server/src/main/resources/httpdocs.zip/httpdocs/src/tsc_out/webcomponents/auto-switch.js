var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { customElement, property } from 'lit-element';
import { RocWctButton, EServerEvent } from '../base/rocwct-lib';
import * as rocwct from '../rocwct';
let AutoSwitch = class AutoSwitch extends RocWctButton {
    constructor() {
        super(...arguments);
        this.icon = "auto-mode.svg";
        this.label = "Auto-Mode";
    }
    static get styles() {
        return [
            RocWctButton.stylesRocWctButton,
        ];
    }
    connectedCallback() {
        super.connectedCallback();
        this.registerServerEvent(EServerEvent.auto, res => this.onServerEvent(res));
        this.sendInitCommand();
    }
    sendInitCommand() {
        rocwct.send('<sys cmd="getstate"/>');
    }
    onServerEvent(event) {
        this.on = event.auto.cmd === 'on';
    }
    handleClick() {
        rocwct.send(`<auto cmd="${this.on === true ? "off" : "on"}" controlcode="" slavecode="" />`);
    }
};
__decorate([
    property({ type: String, attribute: "icon" })
], AutoSwitch.prototype, "icon", void 0);
__decorate([
    property({ type: String, attribute: "label" })
], AutoSwitch.prototype, "label", void 0);
AutoSwitch = __decorate([
    customElement('auto-switch')
], AutoSwitch);
export { AutoSwitch };
//# sourceMappingURL=auto-switch.js.map