var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { customElement, property } from 'lit-element';
import { EServerEvent, RocWctLocoDependentButton } from '../base/rocwct-lib';
import * as rocwct from '../rocwct';
let LocoAutoSwitch = class LocoAutoSwitch extends RocWctLocoDependentButton {
    constructor() {
        super(...arguments);
        this.locoId = null;
        this.icon = "play.svg";
        this.label = "Lok-Auto";
        this.activateGlobalAuto = false;
        this.startStopLoco = false;
    }
    static get styles() {
        return [
            RocWctLocoDependentButton.stylesRocWctLocoDependentButton
        ];
    }
    connectedCallback() {
        super.connectedCallback();
        this.registerServerEvent(EServerEvent.lc, res => this.handleLocoEvent(res, e => this.onServerEventLoco(e)));
        this.registerServerEvent(EServerEvent.auto, res => this.onServerEventAuto(res));
    }
    handleClick() {
        this.sendDirCmd();
    }
    onLocoIdChange() {
        this.sendInitCommand();
    }
    sendInitCommand() {
        rocwct.send('<sys cmd="getstate"/>'); // get global state 
        rocwct.send(`<lc id="${this.locoId}"  />`); // empty lc-command triggers server event with current state of loco
    }
    onServerEventLoco(event) {
        this.on = !event.lc.manual;
    }
    onServerEventAuto(event) {
        // if global auto mode goes to 'off' and attrStartStopLoco is true, the loco auto mode should go to manual and stop
        if (event.auto.cmd !== "on" && this.startStopLoco === true) {
            rocwct.send(`<lc id="${this.locoId}" cmd="setmanualmode" controlcode="" slavecode="" />`);
            rocwct.send(`<lc id="${this.locoId}" cmd="stop" controlcode="" slavecode="" />`);
        }
    }
    sendDirCmd() {
        let doActivateAutoMode = false;
        if (this.on === false) {
            doActivateAutoMode = true;
        }
        else {
            doActivateAutoMode = false;
        }
        // activate global auto mode when loco auto will be activated (if specified by attribute)
        if (doActivateAutoMode === true && this.activateGlobalAuto === true) {
            rocwct.send(`<auto cmd="on" />`);
        }
        // activate loco auto mode
        rocwct.send(`<lc id="${this.locoId}" cmd="${doActivateAutoMode === true ? 'resetmanualmode' : 'setmanualmode'}" controlcode="" slavecode="" />`);
        // trigger go-/stop-command
        if (this.startStopLoco === true) {
            rocwct.send(`<lc id="${this.locoId}" cmd="${doActivateAutoMode === true ? 'go' : 'stop'}" controlcode="" slavecode="" />`);
        }
    }
};
__decorate([
    property({ type: String, attribute: "loco-id" })
], LocoAutoSwitch.prototype, "locoId", void 0);
__decorate([
    property({ type: String })
], LocoAutoSwitch.prototype, "icon", void 0);
__decorate([
    property({ type: String })
], LocoAutoSwitch.prototype, "label", void 0);
__decorate([
    property({ type: Boolean, attribute: "activate-global-auto" })
], LocoAutoSwitch.prototype, "activateGlobalAuto", void 0);
__decorate([
    property({ type: Boolean, attribute: "start-stop-loco" })
], LocoAutoSwitch.prototype, "startStopLoco", void 0);
LocoAutoSwitch = __decorate([
    customElement('loco-auto-switch')
], LocoAutoSwitch);
export { LocoAutoSwitch };
//# sourceMappingURL=loco-auto-switch.js.map