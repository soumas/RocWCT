var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, customElement, css, property } from 'lit-element';
import { RocWctLitElement, EServerEvent } from '../base/rocwct-lib';
import * as rocwct from '../rocwct';
let LocoChooser = class LocoChooser extends RocWctLitElement {
    constructor() {
        super(...arguments);
        this.locoList = new Array();
        this.selectedLoco = null;
    }
    static get styles() {
        return [
            RocWctLitElement.stylesRocWctLitElement,
            css `.locobox { padding:4px; cursor:pointer; }`,
            css `.selected { border:solid 2px #FCAE01; padding:2px;  }`,
        ];
    }
    connectedCallback() {
        super.connectedCallback();
        this.registerServerEvent(EServerEvent.lclist, res => this.onServerEventLc(res));
        this.sendInitCommand();
    }
    sendInitCommand() {
        rocwct.send(`<model cmd="lclist" />`);
    }
    render() {
        return html `${this.locoList.length > 0
            ? html `<div>
            ${this.locoList.map(loco => html `
              <div class="locobox ${this.selectedLoco === loco.id ? 'selected' : ''}">
                <loco-display loco-id="${loco.id}" @click="${this.handleLocoboxClick}"></loco-display>
              </div>
            `)}
            </div>`
            : html ``}`;
    }
    onServerEventLc(event) {
        this.locoList = new Array();
        event.lclist.lc.forEach((loco, k) => {
            if (loco.show === true) {
                this.locoList.push(loco);
            }
        });
        // select first loco if no loco is selected
        if (this.selectedLoco === null && this.locoList.length > 0) {
            this.selectLoco(this.locoList[0].id);
        }
    }
    handleLocoboxClick(e) {
        this.selectLoco(e.target.getAttribute('loco-id'));
    }
    selectLoco(id) {
        this.selectedLoco = id;
        let onLocoChange = new CustomEvent('onLocoChange', {
            detail: { locoid: this.selectedLoco },
            bubbles: true,
            composed: true
        });
        this.dispatchEvent(onLocoChange);
    }
};
__decorate([
    property({ type: Array })
], LocoChooser.prototype, "locoList", void 0);
__decorate([
    property({ type: String })
], LocoChooser.prototype, "selectedLoco", void 0);
LocoChooser = __decorate([
    customElement('loco-chooser')
], LocoChooser);
export { LocoChooser };
//# sourceMappingURL=loco-chooser.js.map