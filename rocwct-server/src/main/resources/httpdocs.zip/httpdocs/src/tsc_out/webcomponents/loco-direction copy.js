var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, customElement, property } from 'lit-element';
import { RocWctLitElement, EServerEvent } from '../base/rocwct-lib';
import * as rocwct from '../rocwct';
let LocoDirection = class LocoDirection extends RocWctLitElement {
    constructor() {
        super(...arguments);
        this.forward = null;
        this.icon = null;
        this.on = null;
        this.locoId = null;
        this.direction = null;
        this.iconForward = "chevron-right.svg";
        this.iconBackward = "chevron-left.svg";
    }
    static get styles() {
        return [
            RocWctLitElement.baseStyles
        ];
    }
    connectedCallback() {
        super.connectedCallback();
        this.registerServerEvent(EServerEvent.lc, this.locoId, res => this.onServerEvent(res));
        this.sendInitCommand();
    }
    render() {
        return html `${this.forward != null
            ? html `<div class="btn-container">
                <div class="btn icon ${this.on === true ? "on" : "off"}" style="-webkit-mask: url(${this.iconSetRoot}/${this.icon}) no-repeat center; mask: url(${this.iconSetRoot}/${this.icon}) no-repeat center;" @click="${this.handleClick}"></div>
            </div>`
            : html ``}`;
    }
    handleClick() {
        this.sendDirCmd();
    }
    sendInitCommand() {
        // empty lc-command triggers server event with current state of loco
        rocwct.send(`<lc id="${this.locoId}"  />`);
    }
    onServerEvent(event) {
        this.forward = event.lc.dir;
        this.updateButtonState();
    }
    sendDirCmd() {
        let dirval = '';
        if (this.direction === 'forward') {
            dirval = 'true';
        }
        else if (this.direction === 'backward') {
            dirval = 'false';
        }
        else {
            dirval = this.forward === true ? "false" : "true";
        }
        rocwct.send(`<lc id="${this.locoId}" dir="${dirval}" />`);
    }
    updateButtonState() {
        if (this.direction === 'forward') {
            this.icon = this.iconForward;
            this.on = this.forward === true;
        }
        else if (this.direction === 'backward') {
            this.icon = this.iconBackward;
            this.on = this.forward === false;
        }
        else {
            this.icon = (this.forward === true) ? this.iconForward : this.iconBackward;
            this.on = true;
        }
    }
};
__decorate([
    property({ type: Boolean })
], LocoDirection.prototype, "forward", void 0);
__decorate([
    property({ type: String })
], LocoDirection.prototype, "icon", void 0);
__decorate([
    property({ type: String })
], LocoDirection.prototype, "on", void 0);
__decorate([
    property({ type: String, attribute: "loco-id" })
], LocoDirection.prototype, "locoId", void 0);
__decorate([
    property({ type: String, attribute: "direction" })
], LocoDirection.prototype, "direction", void 0);
__decorate([
    property({ type: String, attribute: "icon-forward" })
], LocoDirection.prototype, "iconForward", void 0);
__decorate([
    property({ type: String, attribute: "icon-backward" })
], LocoDirection.prototype, "iconBackward", void 0);
LocoDirection = __decorate([
    customElement('loco-direction')
], LocoDirection);
export { LocoDirection };
//# sourceMappingURL=loco-direction copy.js.map