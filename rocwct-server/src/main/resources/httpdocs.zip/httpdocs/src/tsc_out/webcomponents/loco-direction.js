var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { customElement, property } from 'lit-element';
import { EServerEvent, RocWctLocoDependentButton } from '../base/rocwct-lib';
import * as rocwct from '../rocwct';
let LocoDirection = class LocoDirection extends RocWctLocoDependentButton {
    constructor() {
        super(...arguments);
        this.locoId = null;
        this.direction = null;
        this.iconForward = "chevron-right.svg";
        this.iconBackward = "chevron-left.svg";
        this.labelForward = "Vorwärts";
        this.labelBackward = "Rückwärts";
        this.forward = null;
        this.icon = null;
        this.label = null;
    }
    static get styles() {
        return [
            RocWctLocoDependentButton.stylesRocWctLocoDependentButton,
        ];
    }
    connectedCallback() {
        super.connectedCallback();
        this.registerServerEvent(EServerEvent.lc, res => this.handleLocoEvent(res, e => this.onServerEvent(e)));
    }
    onLocoIdChange() {
        this.sendInitCommand();
    }
    handleClick() {
        this.sendDirCmd();
    }
    sendInitCommand() {
        // trigger empty lc command results in statusinf for specific loco
        rocwct.send(`<lc id="${this.locoId}"  />`);
    }
    onServerEvent(event) {
        this.forward = event.lc.dir;
        this.updateButtonState();
    }
    updateButtonState() {
        if (this.direction === 'forward') {
            this.on = this.forward === true;
            this.icon = this.iconForward;
            this.label = this.labelForward;
        }
        else if (this.direction === 'backward') {
            this.on = this.forward === false;
            this.icon = this.iconBackward;
            this.label = this.labelBackward;
        }
        else {
            this.on = true;
            this.icon = (this.forward === true) ? this.iconForward : this.iconBackward;
            this.label = (this.forward === true) ? this.labelForward : this.labelBackward;
        }
    }
    sendDirCmd() {
        let dirval = '';
        if (this.direction === 'forward') {
            dirval = 'true';
        }
        else if (this.direction === 'backward') {
            dirval = 'false';
        }
        else {
            dirval = this.forward === true ? "false" : "true";
        }
        rocwct.send(`<lc id="${this.locoId}" dir="${dirval}" />`);
    }
};
__decorate([
    property({ type: String, attribute: "loco-id" })
], LocoDirection.prototype, "locoId", void 0);
__decorate([
    property({ type: String, attribute: "direction" })
], LocoDirection.prototype, "direction", void 0);
__decorate([
    property({ type: String, attribute: "icon-forward" })
], LocoDirection.prototype, "iconForward", void 0);
__decorate([
    property({ type: String, attribute: "icon-backward" })
], LocoDirection.prototype, "iconBackward", void 0);
__decorate([
    property({ type: String, attribute: "label-forward" })
], LocoDirection.prototype, "labelForward", void 0);
__decorate([
    property({ type: String, attribute: "label-backward" })
], LocoDirection.prototype, "labelBackward", void 0);
__decorate([
    property({ type: Boolean })
], LocoDirection.prototype, "forward", void 0);
__decorate([
    property({ type: String })
], LocoDirection.prototype, "icon", void 0);
__decorate([
    property({ type: String })
], LocoDirection.prototype, "label", void 0);
LocoDirection = __decorate([
    customElement('loco-direction')
], LocoDirection);
export { LocoDirection };
//# sourceMappingURL=loco-direction.js.map