var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, customElement, css, property } from 'lit-element';
import { RocWctLocoDependentElement, EServerEvent } from '../base/rocwct-lib';
import * as rocwct from '../rocwct';
let LocoDisplay = class LocoDisplay extends RocWctLocoDependentElement {
    constructor() {
        super(...arguments);
        this.locoId = null;
        this.hideDescr = false;
        this.locoImage = null;
        this.locoAddr = null;
        this.locoDescription = null;
        this.locoMode = null;
    }
    static get styles() {
        return [
            RocWctLocoDependentElement.stylesRocWctLocoDependentElement,
            css `div { text-align:center; }`,
            css `img { width:100%; }`
        ];
    }
    connectedCallback() {
        super.connectedCallback();
        this.registerServerEvent(EServerEvent.lc, res => this.handleLocoEvent(res, e => this.onServerEvent(e)));
    }
    render() {
        return html `${this.locoImage != null
            ? html `
        <div class="container">
          <div><img src="/images/rocrail/${this.locoImage}" alt="${this.locoId}" title="${this.locoId}" /></div>
          <div><span class="label">${this.locoId} (${this.locoAddr}) [${this.locoMode}]</span> <span style="display:${(this.hideDescr === false && this.locoDescription !== null && this.locoDescription.length > 0) ? '' : 'none'};" class="label">, ${this.locoDescription}</span></div>
        </div>`
            : html ``}`;
    }
    onLocoIdChange() {
        rocwct.send(`<model cmd="lcprops" />`);
    }
    onServerEvent(e) {
        this.executeIfNotUndefined(e.lc.image, (val) => { this.locoImage = val; });
        this.executeIfNotUndefined(e.lc.addr, (val) => { this.locoAddr = val; });
        this.executeIfNotUndefined(e.lc.desc, (val) => { this.locoDescription = val; });
        this.executeIfNotUndefined(e.lc.mode, (val) => { this.locoMode = val; });
    }
    executeIfNotUndefined(val, func) {
        if (val !== undefined) {
            func(val);
        }
    }
};
__decorate([
    property({ type: String, attribute: "loco-id" })
], LocoDisplay.prototype, "locoId", void 0);
__decorate([
    property({ type: Boolean, attribute: "hide-description" })
], LocoDisplay.prototype, "hideDescr", void 0);
__decorate([
    property({ type: String })
], LocoDisplay.prototype, "locoImage", void 0);
__decorate([
    property({ type: String })
], LocoDisplay.prototype, "locoAddr", void 0);
__decorate([
    property({ type: String })
], LocoDisplay.prototype, "locoDescription", void 0);
__decorate([
    property({ type: String })
], LocoDisplay.prototype, "locoMode", void 0);
LocoDisplay = __decorate([
    customElement('loco-display')
], LocoDisplay);
export { LocoDisplay };
//# sourceMappingURL=loco-display.js.map