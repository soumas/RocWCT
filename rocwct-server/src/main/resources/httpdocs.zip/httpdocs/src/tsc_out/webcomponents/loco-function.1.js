var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, customElement, css, property } from 'lit-element';
import { RocWctLitElement, EServerEvent } from '../base/rocwct-lib';
import * as rocwct from '../rocwct';
let LocoFunction = class LocoFunction extends RocWctLitElement {
    constructor() {
        super(...arguments);
        this.on = null;
        this.locoId = null;
        this.fn = null;
    }
    static get styles() {
        return [
            css `.on::after { content: " ON"; } `,
            css `.off::after { content: "OFF "; } `
        ];
    }
    connectedCallback() {
        super.connectedCallback();
        this.registerServerEvent(EServerEvent.fn, this.locoId, res => this.onServerEvent(res));
        this.sendDirCmd();
    }
    render() {
        return html `${this.on != null
            ? html `<button class="${this.on === true ? "on" : "off"}" @click="${this.handleClick}"><slot name="btnContent">${this.locoId}, ${this.fn}, </slot></button>`
            : html ``}`;
    }
    handleClick() {
        this.sendDirCmd();
    }
    onServerEvent(event) {
        if (!event.fn.hasOwnProperty(this.fn)) {
            return;
        }
        this.on = eval('event.fn.' + this.fn) === true;
    }
    sendDirCmd() {
        let cmd = `<fn id="${this.locoId}" ${this.fn}="${this.on === true ? "false" : "true"}"  />`;
        rocwct.send(cmd);
    }
};
__decorate([
    property({ type: Boolean })
], LocoFunction.prototype, "on", void 0);
__decorate([
    property({ type: String, attribute: "loco-id" })
], LocoFunction.prototype, "locoId", void 0);
__decorate([
    property({ type: String, attribute: "fn" })
], LocoFunction.prototype, "fn", void 0);
LocoFunction = __decorate([
    customElement('loco-function')
], LocoFunction);
export { LocoFunction };
//# sourceMappingURL=loco-function.1.js.map