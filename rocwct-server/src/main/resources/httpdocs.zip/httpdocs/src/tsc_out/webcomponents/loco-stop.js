var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { customElement, property } from 'lit-element';
import { RocWctLocoDependentButton, EServerEvent } from '../base/rocwct-lib';
import * as rocwct from '../rocwct';
let LocoStop = class LocoStop extends RocWctLocoDependentButton {
    constructor() {
        super(...arguments);
        this.icon = "stop.svg";
        this.label = "Stop";
        this.locoId = null;
    }
    static get styles() {
        return [
            RocWctLocoDependentButton.stylesRocWctLocoDependentButton
        ];
    }
    connectedCallback() {
        super.connectedCallback();
        this.on = true;
        this.registerServerEvent(EServerEvent.lc, res => this.handleLocoEvent(res, e => this.onServerEvent(e)));
    }
    onServerEvent(e) {
        super.disabled = e.lc.V === 0;
    }
    handleClick() {
        rocwct.send(`<lc id="${this.locoId}" V="0" controlcode="" slavecode="" />`);
    }
    render() {
        return super.render();
    }
    onLocoIdChange() {
        // trigger empty lc command results in statusinf for specific loco
        rocwct.send(`<lc id="${this.locoId}"  />`);
    }
};
__decorate([
    property({ type: String, attribute: "icon" })
], LocoStop.prototype, "icon", void 0);
__decorate([
    property({ type: String, attribute: "label" })
], LocoStop.prototype, "label", void 0);
__decorate([
    property({ type: String, attribute: "loco-id" })
], LocoStop.prototype, "locoId", void 0);
LocoStop = __decorate([
    customElement('loco-stop')
], LocoStop);
export { LocoStop };
//# sourceMappingURL=loco-stop.js.map