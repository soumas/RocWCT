var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, customElement, css, property } from 'lit-element';
import { RocWctLitElement, EServerEvent } from '../base/rocwct-lib';
import * as rocwct from '../rocwct';
let PowerSwitch = class PowerSwitch extends RocWctLitElement {
    constructor() {
        super(...arguments);
        this.on = null;
    }
    static get styles() {
        return [
            css `.on::after { content: " ON"; } `,
            css `.off::after { content: "OFF "; } `
        ];
    }
    connectedCallback() {
        super.connectedCallback();
        this.registerServerEvent(EServerEvent.state, null, res => this.onServerEvent(res));
        this.sendCmd();
    }
    render() {
        return html `${this.on != null
            ? html `<button class="${this.on === true ? "on" : "off"}" @click="${this.handleClick}"><slot name="btnContent">Power </slot></button>`
            : html ``}`;
    }
    handleClick() {
        this.sendCmd();
    }
    onServerEvent(event) {
        this.on = event.state.power;
    }
    sendCmd() {
        let cmd = `<sys cmd="${this.on === true ? "stop" : "go"}" />`;
        rocwct.send(cmd);
    }
};
__decorate([
    property({ type: Boolean })
], PowerSwitch.prototype, "on", void 0);
PowerSwitch = __decorate([
    customElement('power-switch')
], PowerSwitch);
export { PowerSwitch };
//# sourceMappingURL=power-switch.1.js.map