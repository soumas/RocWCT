var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { customElement, property } from 'lit-element';
import { RocWctButton, EServerEvent } from '../base/rocwct-lib';
import * as rocwct from '../rocwct';
let PowerSwitch = class PowerSwitch extends RocWctButton {
    constructor() {
        super(...arguments);
        this.icon = "power.svg";
        this.label = "Power";
    }
    static get styles() {
        return [
            RocWctButton.stylesRocWctButton
        ];
    }
    connectedCallback() {
        super.connectedCallback();
        this.registerServerEvent(EServerEvent.state, res => this.onServerEvent(res));
        this.sendInitCommand();
    }
    sendInitCommand() {
        rocwct.send('<sys cmd="getstate"/>');
    }
    onServerEvent(event) {
        this.on = event.state.power;
    }
    handleClick() {
        rocwct.send(`<sys cmd="${this.on === true ? "stop" : "go"}" />`);
    }
};
__decorate([
    property({ type: String, attribute: "icon" })
], PowerSwitch.prototype, "icon", void 0);
__decorate([
    property({ type: String, attribute: "label" })
], PowerSwitch.prototype, "label", void 0);
PowerSwitch = __decorate([
    customElement('power-switch')
], PowerSwitch);
export { PowerSwitch };
//# sourceMappingURL=power-switch.js.map