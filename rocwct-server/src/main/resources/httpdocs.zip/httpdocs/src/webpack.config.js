module.exports = {
    entry:"./index.js",
    output: {
        filename:"../../js/rocwct-bundle.js"
    },
    mode: 'development'
}